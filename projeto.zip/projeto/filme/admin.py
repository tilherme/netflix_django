from django.contrib import admin
from .models import *

admin.site.register(Film)
# Register your models here.
